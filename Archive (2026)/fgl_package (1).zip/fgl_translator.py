
import json

class FGLTranslator:
    def __init__(self, lexicon_file='fgl_lexicon.json'):
        with open(lexicon_file, 'r') as f:
            data = json.load(f)
        self.lexicon = data['lexicon']
        self.rules = data['syntax_rules']

        # Build lookup tables
        self.en_to_symbol = {entry['english'].lower(): entry['symbol'] for entry in self.lexicon}
        self.symbol_to_en = {entry['symbol']: entry['english'] for entry in self.lexicon}

    def to_fgl(self, text):
        tokens = text.lower().split()
        output = []
        for token in tokens:
            if token in self.en_to_symbol:
                output.append(self.en_to_symbol[token])
            else:
                output.append(f"[{token}]")  # unknown word marker
        return ' '.join(output)

    def to_english(self, fgl_text):
        symbols = fgl_text.split()
        output = []
        for symbol in symbols:
            if symbol in self.symbol_to_en:
                output.append(self.symbol_to_en[symbol])
            else:
                output.append(f"[{symbol}]")  # unknown symbol marker
        return ' '.join(output)

if __name__ == "__main__":
    t = FGLTranslator()
    sample = "light speaks to darkness"
    encoded = t.to_fgl(sample)
    decoded = t.to_english(encoded)
    print("Input:", sample)
    print("Encoded:", encoded)
    print("Decoded:", decoded)
