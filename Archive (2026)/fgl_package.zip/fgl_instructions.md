# Fractal Genesis Language (FGL) - Implementation Instructions

This document explains how to build a working English ↔ FGL translator that performs lossless roundtrip translation when metadata is preserved.

## Files in this package
- `fgl_seed_lexicon.json` : seed lexicon (120 entries)
- `fgl_language_spec.json` : language specification (tokens, metadata schema, serialization rules)
- `fgl_instructions.md` : this implementation instructions file
- `fgl_package.zip` : zipped package of all files

## Overview
Implement two main pipelines:
- `english_to_fgl(sentence)` -> produces FGL JSON serialization
- `fgl_to_english(fgl_json)` -> reconstructs English sentence (exact if `orth` preserved)

Recommended stack: Python 3.10+, spaCy for NLP, Flask/FastAPI for an API, JSON for serialization.

## Core modules
1. tokenizer.py
   - Tokenize English using spaCy
   - Detect multiword tokens and named entities (NE)
   - Output token list with POS, lemma, orthography, dependency relations

2. mapper.py
   - Lookup lexicon entries (by lemma or orth)
   - Return lexid, glyph, archetype, and base pos
   - For unknowns, generate UNK_<hash> and store 'orth' in meta

3. serializer.py
   - Build clause structures in canonical order (Subject -> Verb -> Object -> Adjuncts)
   - Fill metadata: pers, num, tense, def, case, idiom, refid, voice, mod, mood, orth
   - Output FGL JSON: { seed: {...}, clauses: [...], terminator: "•" }

4. parser.py
   - Parse FGL JSON into internal structures for realization

5. realizer.py
   - Realize English surface forms from lexid+meta
   - Inflect verbs/nouns based on metadata; use ortho when available for exact roundtrip
   - Handle auxiliaries/modals and generate determiners

6. api.py (optional)
   - Flask/FastAPI endpoints:
     - POST /translate_to_fgl { "text": "..." } -> returns fgl_json
     - POST /translate_to_english { "fgl": { ... } } -> returns {"text": "..."}
     - GET /lexicon/{lexid} -> returns lexicon entry

## Pipelines (high-level)

### English -> FGL
1. nlp = spacy.load("en_core_web_sm")
2. doc = nlp(sentence)
3. detect multiword and named entities (longest match)
4. for each token:
   - find lexicon entry by lemma or orth
   - build token meta (pers, case, num, tense, mod, voice, idiom, orth)
5. build canonical clause order using dependency parse
6. determine seed (mood) and terminator
7. serialize to JSON

### FGL -> English
1. parse fgl_json
2. for each token, fetch lexicon entry
3. if meta.orth present or idiom=1, use orth text directly (ensures exact roundtrip)
4. else, realize word form from lex_entry['english'] with inflection rules
5. reconstruct sentence by joining tokens in order, adding determiners and punctuation
6. return exact original if orth preserved

## Tests
Create unit tests for:
- Pronouns, tense, modals, passive voice
- Multiword idioms and NE roundtrip
- Nested clauses and causation (∵ ... ∴)
- Unknown tokens preserving orth

## Notes on roundtrip fidelity
- To guarantee exact roundtrip, always include `meta.orth` for tokens where the original surface form must be preserved (irregular forms, capitalization, punctuation, named entities).
- If you prefer compact glyph-only strings for human reading, store metadata header alongside the glyph string (e.g., base64 encoded JSON) to allow lossless decoding.

## Example usage (Python pseudocode)
```python
from fgl import english_to_fgl, fgl_to_english, load_lexicon
lex = load_lexicon("fgl_seed_lexicon.json")
fgl = english_to_fgl("The old woman will always love the small child.", lex)
eng = fgl_to_english(fgl, lex)
assert eng == "The old woman will always love the small child."
```

## Extending the lexicon
- Log UNK tokens and curate them regularly
- Add MW_xxx lexids for frequent idioms
- Version lexicon files and maintain lexid stability

## Serialization compactness (optional)
- Use CBOR / Protobuf for binary format
- Map lexid -> integer index to compress size
- Pack metadata into bitfields when appropriate

## Final note
This package is a seed framework. As you use it, expand lexicon entries and tune realization rules for natural phrasing. For ritual or meditative uses, you can display glyphs with or without the orthography; for computational uses keep orth metadata to ensure exactness.
